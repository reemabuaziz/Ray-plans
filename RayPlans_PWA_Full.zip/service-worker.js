const CACHE_NAME="ray-cache";
self.addEventListener("install",e=>{
e.waitUntil(caches.open(CACHE_NAME).then(cache=>cache.addAll(["./","./index.html"])));
});
self.addEventListener("fetch",e=>{
e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request)));
});
